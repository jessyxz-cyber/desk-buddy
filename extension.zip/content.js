// Runs inside YouTube / YouTube Music tabs: reports title, playback time, pause state and video id.
setInterval(() => {
  const onMusic = location.hostname.startsWith("music.");
  if (!onMusic && location.pathname !== "/watch") return;   // ignore homepage hover previews

  const v = document.querySelector("video");
  if (!v || !isFinite(v.duration)) return;

  const md = navigator.mediaSession && navigator.mediaSession.metadata;
  const title = (md && md.title) || document.title.replace(/ - YouTube.*$/, "");
  const artist = (md && md.artist) || "";
  const videoId = new URLSearchParams(location.search).get("v") || "";

  try {
    chrome.runtime.sendMessage({
      kind: "yt",
      title,
      artist,
      videoId,
      time: v.currentTime,
      duration: v.duration,
      paused: v.paused || v.ended
    });
  } catch (e) { /* extension reloaded; refresh the tab */ }
}, 150);
