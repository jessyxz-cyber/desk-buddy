// Runs inside open.spotify.com (Spotify Web Player): reports what is playing and WHERE in the song it is.
//
// Spotify's clock text only shows whole seconds and changes at an unknown moment inside each second,
// so reading it naively makes lyrics late. We use the best source available, in this order:
//   1. the exact position Spotify gives the media session (spotify_main.js)
//   2. the progress-bar fill (finer than the clock text), if it agrees with the clock text
//   3. the clock text + 0.6 s (the average amount the text lags behind the real position)
// Between updates we keep our own clock running, so it also works when the tab is in the background.

function toSec(txt) {
  if (!txt) return -1;
  const parts = txt.trim().split(":").map(Number);
  if (parts.some(isNaN)) return -1;
  return parts.reduce((a, v) => a * 60 + v, 0);
}

let anchorPos = -1, anchorAt = 0;       // our clock: position (s) at a moment (ms)
let anchorTitle = "", lastDomPos = -2, lastPlaying = false;
let exactTrack = false;                 // got an exact position from Spotify for this song

const clockNow = () => performance.now();
function estimate(playing) {
  return anchorPos < 0 ? -1 : anchorPos + (playing ? (clockNow() - anchorAt) / 1000 : 0);
}
function setAnchor(pos) { anchorPos = pos; anchorAt = clockNow(); }

window.addEventListener("message", (e) => {
  const d = e.data;
  if (e.source !== window || !d || d.__mochi !== "pos" || typeof d.position !== "number") return;
  // whole-number positions carry no extra precision, only trust fractional ones
  if (Math.abs(d.position - Math.round(d.position)) > 0.001) {
    exactTrack = true;
    setAnchor(d.position);
  }
});

function progressBarPos(dur, textPos) {
  const el = document.querySelector('[data-testid="progress-bar"]');
  if (!el || !(dur > 0) || textPos < 0) return -1;
  const pct = parseFloat(getComputedStyle(el).getPropertyValue("--progress-bar-transform"));
  if (isNaN(pct)) return -1;
  const p = (pct / 100) * dur;
  return (p >= textPos - 0.3 && p < textPos + 1.3) ? p : -1;      // only if it agrees with the clock text
}

setInterval(() => {
  const md = navigator.mediaSession && navigator.mediaSession.metadata;
  if (!md || !md.title) return;                                   // nothing loaded in this tab

  // playing or paused? the media session is the most reliable, the button label is the fallback
  const ps = navigator.mediaSession.playbackState;
  const btn = document.querySelector('[data-testid="control-button-playpause"]');
  const label = btn ? (btn.getAttribute("aria-label") || "") : "";
  const playing = ps === "playing" ? true : ps === "paused" ? false : /^pause/i.test(label);

  const posEl = document.querySelector('[data-testid="playback-position"]');
  const durEl = document.querySelector('[data-testid="playback-duration"]');
  const pos = toSec(posEl && posEl.textContent);                  // whole seconds
  let dur = -1;
  if (durEl) {
    const t = durEl.textContent.trim();
    dur = t.startsWith("-") ? (pos >= 0 ? pos + toSec(t.slice(1)) : -1) : toSec(t);   // Spotify can show time left
  }

  const now = clockNow();
  const newSong = md.title !== anchorTitle;
  const domChanged = pos !== lastDomPos;

  if (newSong) {
    anchorTitle = md.title; exactTrack = false; lastDomPos = pos;
    if (pos >= 0) setAnchor(progressBarPos(dur, pos) >= 0 ? progressBarPos(dur, pos) : pos + 0.3);
  } else if (playing !== lastPlaying) {
    if (playing) { anchorAt = now; }                              // resume: keep counting from where we froze
    else { setAnchor(estimate(true)); }                           // pause: freeze the clock here
  }
  lastPlaying = playing;

  if (!newSong && domChanged && pos >= 0) {
    lastDomPos = pos;
    const est = estimate(playing);
    if (!exactTrack) {
      const fine = progressBarPos(dur, pos);
      setAnchor(fine >= 0 ? fine : pos + (playing ? 0.6 : 0.5));  // re-sync every second (also catches seeks)
    } else if (est < 0 || Math.abs(est - (pos + 0.5)) > 1.8) {
      exactTrack = false;                                         // seek or stall that Spotify did not announce
      setAnchor(pos + 0.5);
    }
  }

  try {
    chrome.runtime.sendMessage({
      kind: "spotify",
      title: md.title,
      artist: md.artist || "",
      album: md.album || "",
      playing,
      pos: estimate(playing),
      dur
    });
  } catch (e) { /* extension reloaded; refresh the tab */ }
}, 200);
