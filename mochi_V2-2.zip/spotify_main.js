// Runs inside the Spotify page itself (not in the extension sandbox).
// If Spotify tells the browser the exact playback position (media session), copy it to the extension.
(function () {
  try {
    const ms = navigator.mediaSession;
    if (!ms || typeof ms.setPositionState !== "function") return;
    const orig = ms.setPositionState.bind(ms);
    ms.setPositionState = function (state) {
      try {
        if (state && typeof state.position === "number") {
          window.postMessage({ __mochi: "pos", position: state.position, duration: state.duration, rate: state.playbackRate || 1 }, "*");
        }
      } catch (e) { /* never break Spotify */ }
      return orig.apply(null, arguments);
    };
  } catch (e) { /* never break Spotify */ }
})();
