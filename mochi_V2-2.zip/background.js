// ===== SETTINGS =====
const ESP_IP = "192.168.1.50";  // IP shown on the OLED at boot (also change it in manifest.json)
// Lyric timing (seconds, + = lyrics appear earlier). These are only the starting values:
// Mochi's web page has +/- buttons for both and the extension picks them up automatically.
let offYt = 0.3;                // YouTube
let offSp = 0.3;                // Spotify
const THUMB_GAMMA = 0.85;       // thumbnail brightness: below 1 = brighter, above 1 = darker
// ====================

// ---------------------------------------------------------------- helpers
const clean = (s) =>
  s.replace(/\(.*?\)|\[.*?\]/g, " ")
   .replace(/\b(official|music video|video|audio|lyrics?|lyrical|full song|hd|4k)\b/gi, " ")
   .replace(/\s*[|•].*$/, " ")
   .replace(/\s+-\s+(remaster(ed)?|live|radio edit|single version|mono|stereo|acoustic|from\b).*$/i, " ")
   .replace(/\s+/g, " ")
   .trim();

// The OLED font is ASCII only
const toAscii = (s) =>
  s.replace(/[‘’]/g, "'").replace(/[“”]/g, '"')
   .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
   .replace(/[^\x20-\x7E]/g, "");

// ---------------------------------------------------------------- Synced lyrics (YouTube + Spotify)
let key = "", lines = [], lastIdx = -2, lastPaused = null, loading = false;
let activeSrc = "", activeAt = 0;       // which player the lyrics follow ("yt" or "spotify")
const lyricCache = new Map();

// The player's position at the moment of the last message; between messages we keep counting ourselves,
// so lyrics stay on time even when Chrome slows the tab down in the background.
let clock = { pos: -1, at: 0, playing: false, src: "" };
const nowPos = () => (clock.pos < 0 ? -1 : clock.pos + (clock.playing ? (Date.now() - clock.at) / 1000 : 0));

function parseLRC(lrc) {
  const out = [];
  for (const row of lrc.split("\n")) {
    const m = row.match(/^\[(\d+):(\d+(?:\.\d+)?)\](.*)$/);
    if (m) out.push({ t: +m[1] * 60 + +m[2], text: toAscii(m[3]).trim() });
  }
  return out;
}

async function search(q) {
  try {
    const r = await fetch("https://lrclib.net/api/search?q=" + encodeURIComponent(q));
    return r.ok ? await r.json() : [];
  } catch (e) { return []; }
}

// exact match by track + artist + album + length (Spotify gives all four)
async function getExact(m) {
  try {
    const q = new URLSearchParams({
      track_name: clean(m.title),
      artist_name: (m.artist || "").split(",")[0].trim(),
      album_name: m.album || "",
      duration: String(Math.round(m.duration))
    });
    const r = await fetch("https://lrclib.net/api/get?" + q);
    if (!r.ok) return [];
    const j = await r.json();
    return j && j.syncedLyrics ? [j] : [];
  } catch (e) { return []; }
}

async function loadLyrics(m) {
  const spotify = m.src === "spotify";
  const ck = m.src + "|" + m.title + "|" + (m.artist || "") + "|" + Math.round(m.duration);
  if (lyricCache.has(ck)) return lyricCache.get(ck);

  const tol = spotify ? 6 : 20;                                   // Spotify lengths are exact, YouTube videos have intros
  const artist = (m.artist || "").replace(/ - Topic$/, "");
  const jobs = spotify
    ? [getExact(m), search(artist + " " + clean(m.title)), search(clean(m.title))]
    : [search(clean(m.title)), search(clean(m.title + " " + artist))];
  const batches = await Promise.all(jobs);                        // all lookups at once = faster start

  let found = [];
  for (const results of batches) {
    const ok = results
      .filter((x) => x.syncedLyrics && (!(m.duration > 0) || Math.abs(x.duration - m.duration) < tol))
      .sort((a, b) => Math.abs(a.duration - m.duration) - Math.abs(b.duration - m.duration));
    if (ok.length) { found = parseLRC(ok[0].syncedLyrics); break; }
  }
  lyricCache.set(ck, found);
  return found;
}

// Mochi answers "ok|<YouTube ms>|<Spotify ms>": the timing chosen on its web page
function readOffsets(txt) {
  const p = String(txt).split("|");
  if (p.length >= 3) {
    const y = parseInt(p[1], 10), s = parseInt(p[2], 10);
    if (!isNaN(y)) offYt = y / 1000;
    if (!isNaN(s)) offSp = s / 1000;
  }
}

async function send(text, ms = 3000, src = "yt") {
  try {
    const r = await fetch(`http://${ESP_IP}/lyric?ms=${ms}&src=${src}`, {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: text
    });
    readOffsets(await r.text());
  } catch (e) { /* ESP32 offline */ }
}

// Shows the lyric line that belongs to the current position (called every 40 ms and on every message)
async function tick() {
  if (!lines.length || loading || !clock.playing || clock.pos < 0) return;
  const t = nowPos() + (clock.src === "spotify" ? offSp : offYt);
  let idx = -1;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].t <= t) idx = i; else break;
  }
  if (idx === lastIdx) return;
  lastIdx = idx;
  if (idx < 0) { await send("", 3000, clock.src); return; }
  const next = lines[idx + 1];
  const ms = Math.round(((next ? next.t : lines[idx].t + 4) - lines[idx].t) * 1000);
  await send(lines[idx].text, ms, clock.src);
}
setInterval(tick, 40);

// m = { src: "yt" | "spotify", title, artist, album?, time (seconds), duration (seconds), paused, videoId? }
async function handle(m) {
  const now = Date.now();
  if (m.src === "yt") maybeSendThumb(m);

  if (m.paused) {
    if (activeSrc && activeSrc !== m.src) return;                 // a paused tab must not wipe lyrics of the player that is playing
  } else {
    if (activeSrc && activeSrc !== m.src && now - activeAt < 3000) return;   // another player is active right now
    activeSrc = m.src; activeAt = now;
  }
  clock = { pos: m.time, at: now, playing: !m.paused, src: m.src };

  const k = m.src + "|" + m.title + "|" + Math.round(m.duration);

  if (k !== key) {                       // new song
    key = k; lines = []; lastIdx = -2; loading = true;
    const found = await loadLyrics(m).catch(() => []);
    if (key !== k) return;               // song changed again while loading
    lines = found; loading = false;
    if (!lines.length && m.src !== "spotify") await send("No synced lyrics", 3000, m.src);   // on Spotify the Now Playing card stays visible instead
  }
  if (loading) return;

  if (m.paused) {                        // clear on pause
    if (lastPaused !== true) { lastPaused = true; lastIdx = -2; await send("", 3000, m.src); }
    return;
  }
  lastPaused = false;
  tick();
}

// ---------------------------------------------------------------- YouTube thumbnail
// Photo -> 128x64 black/white (Floyd-Steinberg dithering) in the SSD1306 memory layout:
// byte = x + (y / 8) * 128, bit = y % 8 (1 = lit pixel).
function toOledBuffer(rgba, W, H) {
  const n = W * H;
  const g = new Float32Array(n);
  for (let i = 0; i < n; i++) g[i] = 0.299 * rgba[i * 4] + 0.587 * rgba[i * 4 + 1] + 0.114 * rgba[i * 4 + 2];

  // auto-levels: stretch the 2%..98% brightness range so dull thumbnails still show detail
  const hist = new Uint32Array(256);
  for (let i = 0; i < n; i++) hist[Math.max(0, Math.min(255, Math.round(g[i])))]++;
  let lo = 0, hi = 255, acc = 0;
  for (let v = 0; v < 256; v++) { acc += hist[v]; if (acc >= n * 0.02) { lo = v; break; } }
  acc = 0;
  for (let v = 255; v >= 0; v--) { acc += hist[v]; if (acc >= n * 0.02) { hi = v; break; } }
  if (hi - lo < 16) { lo = 0; hi = 255; }
  for (let i = 0; i < n; i++) {
    const v = Math.min(1, Math.max(0, (g[i] - lo) / (hi - lo)));
    g[i] = 255 * Math.pow(v, THUMB_GAMMA);
  }

  const out = new Uint8Array(n / 8);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      const old = g[i], nw = old < 128 ? 0 : 255, err = old - nw;
      if (nw) out[x + (y >> 3) * W] |= 1 << (y & 7);
      if (x + 1 < W) g[i + 1] += err * 7 / 16;
      if (y + 1 < H) {
        if (x > 0) g[i + W - 1] += err * 3 / 16;
        g[i + W] += err * 5 / 16;
        if (x + 1 < W) g[i + W + 1] += err * 1 / 16;
      }
    }
  }
  return out;
}

async function sendThumb(videoId) {
  const r = await fetch(`https://i.ytimg.com/vi/${videoId}/mqdefault.jpg`);
  if (!r.ok) return;
  const bmp = await createImageBitmap(await r.blob());
  const W = 128, H = 64;
  const canvas = new OffscreenCanvas(W, H);
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  ctx.imageSmoothingQuality = "high";
  const scale = Math.max(W / bmp.width, H / bmp.height);    // fill the screen, crop the rest
  const sw = W / scale, sh = H / scale;
  ctx.drawImage(bmp, (bmp.width - sw) / 2, (bmp.height - sh) / 2, sw, sh, 0, 0, W, H);
  const bytes = toOledBuffer(ctx.getImageData(0, 0, W, H).data, W, H);
  const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
  await fetch(`http://${ESP_IP}/thumb`, { method: "POST", headers: { "Content-Type": "text/plain" }, body: hex });
}

let thumbId = "", thumbSentAt = 0;
function maybeSendThumb(m) {
  if (!m.videoId) return;
  const now = Date.now();
  if (m.videoId === thumbId && now - thumbSentAt < 45000) return;   // resent every 45 s in case the ESP32 rebooted
  thumbId = m.videoId; thumbSentAt = now;
  sendThumb(m.videoId).catch(() => {});
}

// ---------------------------------------------------------------- Spotify now playing
let spKey = "", spSentAt = 0;
function handleSpotify(m) {
  const now = Date.now();
  const title = toAscii(m.title || "") || (m.title ? "Unknown" : "");
  const artist = toAscii(m.artist || "");
  const k = title + "|" + artist + "|" + m.playing;
  if (k === spKey && now - spSentAt < 3000) return;               // only on change, plus a 3 s heartbeat
  spKey = k; spSentAt = now;
  const q = "t=" + encodeURIComponent(title) + "&a=" + encodeURIComponent(artist) +
            "&p=" + Math.round(m.pos) + "&d=" + Math.round(m.dur) + "&pl=" + (m.playing ? 1 : 0);
  fetch(`http://${ESP_IP}/np?${q}`, { method: "POST" })
    .then((r) => r.text()).then(readOffsets).catch(() => {});
}

chrome.runtime.onMessage.addListener((m) => {
  if (m.kind === "spotify") {
    handleSpotify(m);
    handle({ src: "spotify", title: m.title, artist: m.artist, album: m.album, time: m.pos, duration: m.dur, paused: !m.playing });
  } else {
    handle({ ...m, src: "yt" });
  }
});
